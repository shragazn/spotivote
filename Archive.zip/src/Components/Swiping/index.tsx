import Swiping from "./Swiping";

export default Swiping;
